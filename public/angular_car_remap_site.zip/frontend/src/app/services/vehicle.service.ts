
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({ providedIn: 'root' })
export class VehicleService {
  constructor(private http: HttpClient) {}

  lookupByReg(reg: string) {
    return this.http.get(`/api/vrm/${reg}`);
  }

  getMakes() {
    return this.http.get<string[]>(`/api/vehicles/makes`);
  }

  getModels(make: string) {
    return this.http.get<string[]>(`/api/vehicles/${make}/models`);
  }

  getYears(make: string, model: string) {
    return this.http.get<string[]>(`/api/vehicles/${make}/${model}/years`);
  }

  getVariants(make: string, model: string, year: string) {
    return this.http.get<string[]>(`/api/vehicles/${make}/${model}/${year}/variants`);
  }
}
