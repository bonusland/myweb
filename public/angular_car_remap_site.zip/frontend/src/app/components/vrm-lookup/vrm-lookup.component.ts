
import { Component } from '@angular/core';
import { VehicleService } from '../../services/vehicle.service';

@Component({
  selector: 'app-vrm-lookup',
  templateUrl: './vrm-lookup.component.html'
})
export class VrmLookupComponent {
  regNumber: string = '';
  vehicleData: any;

  constructor(private vehicleService: VehicleService) {}

  lookupVehicle() {
    this.vehicleService.lookupByReg(this.regNumber).subscribe(data => {
      this.vehicleData = data;
    });
  }
}
