
import { Component, OnInit } from '@angular/core';
import { VehicleService } from '../../services/vehicle.service';

@Component({
  selector: 'app-manual-select',
  templateUrl: './manual-select.component.html'
})
export class ManualSelectComponent implements OnInit {
  makes: string[] = [];
  models: string[] = [];
  years: string[] = [];
  variants: string[] = [];

  selectedMake: string = '';
  selectedModel: string = '';
  selectedYear: string = '';
  selectedVariant: string = '';

  constructor(private vehicleService: VehicleService) {}

  ngOnInit() {
    this.vehicleService.getMakes().subscribe(data => this.makes = data);
  }

  loadModels() {
    this.vehicleService.getModels(this.selectedMake).subscribe(data => this.models = data);
  }

  loadYears() {
    this.vehicleService.getYears(this.selectedMake, this.selectedModel).subscribe(data => this.years = data);
  }

  loadVariants() {
    this.vehicleService.getVariants(this.selectedMake, this.selectedModel, this.selectedYear).subscribe(data => this.variants = data);
  }
}
