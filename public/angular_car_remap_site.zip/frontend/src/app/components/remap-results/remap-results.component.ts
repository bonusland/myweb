
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-remap-results',
  templateUrl: './remap-results.component.html'
})
export class RemapResultsComponent {
  @Input() vehicleData: any;
}
