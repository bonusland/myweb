
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { VrmLookupComponent } from './components/vrm-lookup/vrm-lookup.component';
import { ManualSelectComponent } from './components/manual-select/manual-select.component';
import { RemapResultsComponent } from './components/remap-results/remap-results.component';
import { BookingFormComponent } from './components/booking-form/booking-form.component';

const routes: Routes = [
  { path: 'vrm-lookup', component: VrmLookupComponent },
  { path: 'manual-select', component: ManualSelectComponent },
  { path: 'remap-results', component: RemapResultsComponent },
  { path: 'booking', component: BookingFormComponent },
  { path: '', redirectTo: '/vrm-lookup', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
